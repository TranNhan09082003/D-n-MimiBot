var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/discord/route.js")
R.c("server/chunks/[root-of-the-server]__07l1z41._.js")
R.c("server/chunks/[root-of-the-server]__0svjb5q._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_auth_discord_route_actions_1gqjni3.js")
R.m(6106)
module.exports=R.m(6106).exports
