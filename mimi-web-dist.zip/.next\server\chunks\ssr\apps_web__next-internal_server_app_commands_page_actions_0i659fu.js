module.exports=[31022,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_commands_page_actions_0i659fu.js.map