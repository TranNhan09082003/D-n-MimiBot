module.exports=[86958,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_support_page_actions_0ti31ud.js.map