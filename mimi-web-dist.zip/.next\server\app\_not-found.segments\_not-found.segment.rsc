1:"$Sreact.fragment"
2:I[10291,["/_next/static/chunks/3u9m-tqgpe812.js","/_next/static/chunks/1dq9582dulnoy.js"],"default"]
3:I[2968,["/_next/static/chunks/3u9m-tqgpe812.js","/_next/static/chunks/1dq9582dulnoy.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"CMJW9wyiZ97X9EZL7YXXL"}
