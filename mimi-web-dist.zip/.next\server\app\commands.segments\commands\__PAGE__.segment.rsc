1:"$Sreact.fragment"
2:I[45034,["/_next/static/chunks/3u9m-tqgpe812.js","/_next/static/chunks/1dq9582dulnoy.js","/_next/static/chunks/392_miwxgcyr5.js"],"default"]
3:I[82520,["/_next/static/chunks/3u9m-tqgpe812.js","/_next/static/chunks/1dq9582dulnoy.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"pt-32 pb-20","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/392_miwxgcyr5.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"CMJW9wyiZ97X9EZL7YXXL"}
5:null
