globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/CMJW9wyiZ97X9EZL7YXXL/_buildManifest.js",
    "static/CMJW9wyiZ97X9EZL7YXXL/_ssgManifest.js",
    "static/CMJW9wyiZ97X9EZL7YXXL/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0chqqbkmp85s0.js",
    "static/chunks/3h51z8dctsh-l.js",
    "static/chunks/3krzinbo2ukdr.js",
    "static/chunks/43_coi9hpl87a.js",
    "static/chunks/turbopack-20wyt00bpz50i.js"
  ]
};
