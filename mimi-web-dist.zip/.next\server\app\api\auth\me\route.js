var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__0_-uhl9._.js")
R.c("server/chunks/[root-of-the-server]__0svjb5q._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_auth_me_route_actions_1l3l7yw.js")
R.m(36271)
module.exports=R.m(36271).exports
