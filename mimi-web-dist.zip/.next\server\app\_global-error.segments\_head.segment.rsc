1:"$Sreact.fragment"
2:I[82520,["/_next/static/chunks/0e174qpuwv2ay.js","/_next/static/chunks/1dq9582dulnoy.js"],"ViewportBoundary"]
3:I[82520,["/_next/static/chunks/0e174qpuwv2ay.js","/_next/static/chunks/1dq9582dulnoy.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[60329,["/_next/static/chunks/0e174qpuwv2ay.js","/_next/static/chunks/1dq9582dulnoy.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"CMJW9wyiZ97X9EZL7YXXL"}
