module.exports=[65739,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_data-deletion_page_actions_0q6va4m.js.map