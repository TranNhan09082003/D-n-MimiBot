module.exports=[12203,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_changelog_page_actions_1-g1gr-.js.map