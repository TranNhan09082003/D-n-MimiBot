1:"$Sreact.fragment"
2:I[86501,["/_next/static/chunks/3u9m-tqgpe812.js","/_next/static/chunks/1dq9582dulnoy.js","/_next/static/chunks/1u6eh0o_0pbc-.js"],"default"]
3:I[82520,["/_next/static/chunks/3u9m-tqgpe812.js","/_next/static/chunks/1dq9582dulnoy.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"pt-32 pb-20","children":["$","div",null,{"className":"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8","children":[["$","div",null,{"className":"text-center max-w-2xl mx-auto mb-12 space-y-3","children":[["$","h1",null,{"className":"font-heading font-extrabold text-3xl sm:text-4xl text-[#f7f4ff]","children":"Trạng Thái Vận Hành Trực Tiếp"}],["$","p",null,{"className":"text-sm text-[#a5a1b5]","children":"Kiểm tra trạng thái kết nối realtime giữa Discord Gateway, Website API và hệ thống nút phát nhạc."}]]}],["$","$L2",null,{}]]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/1u6eh0o_0pbc-.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"CMJW9wyiZ97X9EZL7YXXL"}
5:null
