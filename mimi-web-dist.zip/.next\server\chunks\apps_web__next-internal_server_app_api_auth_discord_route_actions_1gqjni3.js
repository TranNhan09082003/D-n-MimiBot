module.exports=[27055,(e,o,d)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_auth_discord_route_actions_1gqjni3.js.map