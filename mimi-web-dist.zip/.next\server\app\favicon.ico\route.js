var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/[root-of-the-server]__0svjb5q._.js")
R.c("server/chunks/0rrk_next_dist_esm_build_templates_app-route_1ycl27m.js")
R.c("server/chunks/apps_web__next-internal_server_app_favicon_ico_route_actions_0u51f7q.js")
R.m(57714)
module.exports=R.m(57714).exports
