var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/callback/discord/route.js")
R.c("server/chunks/[root-of-the-server]__0yltio_._.js")
R.c("server/chunks/[root-of-the-server]__0svjb5q._.js")
R.c("server/chunks/044u_web__next-internal_server_app_api_auth_callback_discord_route_actions_21374hw.js")
R.m(29772)
module.exports=R.m(29772).exports
